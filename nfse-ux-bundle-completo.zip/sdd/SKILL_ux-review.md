---
name: "ux-review"
description: "Revisa a UX/CX da aplicação de NFS-e Nacional para pequenas gestoras de imóveis depois do Define e antes do Design, usando o UX_STANDARD.md canônico do projeto e o UX_REVIEW_TEMPLATE.md. Use para revisar jornadas de emissão, histórico, empresa ativa, revisão final, estados, acessibilidade, responsividade, copy, riscos e handoff para o Design. Qualquer MUST bloqueia o Design até correção ou aceite explícito. Não altera o UX_STANDARD.md automaticamente."
license: "MIT"
metadata:
  author: "Roberto Dias Duarte"
  methodology: "Metodologia de Roberto Dias Duarte"
---

# UX Review — NFS-e Nacional para Gestoras de Imóveis

## Quick start

**Pasta do SDD.** Os documentos do SDD ficam em `sdd/` na raiz do projeto — pasta visível, igual em qualquer agente. Se o projeto já tiver `.claude/sdd/`, continue nela. Os documentos ficam lado a lado, sem subpastas.

Ler obrigatoriamente, nessa pasta:
- `DEFINE_{FEATURE}.md`;
- `UX_STANDARD.md`;
- `UX_REVIEW_TEMPLATE.md`.

Ler quando disponíveis: BRAINSTORM da feature, capturas de tela, mockups, design system, tokens, componentes existentes e URLs relacionadas.

Gravar `UX_REVIEW_{FEATURE}.md` na mesma pasta, seguindo o modelo. A fase Design lê esse arquivo dali.

## Quando usar / Quando não usar

Usar depois do Define e antes do Design para revisar a experiência de qualquer feature da aplicação de NFS-e Nacional para gestoras de imóveis.

Priorizar especialmente features de:
- emissão de NFS-e;
- seleção/contexto de empresa;
- tomador;
- tipos de operação;
- revisão final;
- histórico, filtros e duplicação;
- rascunhos;
- cancelamento;
- permissões e perfis;
- estados e mensagens de retorno.

Não usar para alterar o `UX_STANDARD.md`, definir arquitetura técnica, validar regra tributária, auditar segurança como objetivo principal ou aprovar silenciosamente uma feature com `MUST` pendente.

## Dados necessários

Obrigatórios: DEFINE da feature, UX_STANDARD vigente e UX_REVIEW_TEMPLATE vigente.

Complementares: BRAINSTORM, telas, componentes, design system, referências, URLs e evidências do comportamento atual.

Se uma fonte obrigatória estiver ausente, bloquear a conclusão e pedir o artefato. Não reconstruir o padrão de memória. Se o DEFINE estiver em outra pasta, usar essa pasta, sem criar subpastas.

## Procedimento passo a passo

### 1. Carregar o contexto

Extrair do DEFINE: usuário, objetivo, dor, critérios de sucesso, restrições, perfis envolvidos e o que está fora do escopo. Ler a versão e as regras aplicáveis do UX_STANDARD.

### 2. Mapear a jornada

Usar: Before -> Entry -> Core Action -> Feedback -> Recovery -> Completion -> Follow-up.

Em cada etapa, registrar intenção, risco, fricção, feedback necessário e recuperação.

### 3. Aplicar os riscos críticos do projeto

Para features que possam afetá-los, verificar explicitamente:
- empresa/CNPJ errado;
- tomador errado;
- valor incorreto;
- tipo de operação incorreto;
- emissão sem revisão final;
- perda de dados preenchidos;
- cancelamento sem confirmação reforçada.

Quando uma violação for comprovada e houver regra canônica correspondente, classificar como `MUST`.

### 4. Avaliar conformidade canônica

Para cada regra relevante do UX_STANDARD, marcar `CONFORME`, `MUST`, `SHOULD`, `COULD`, `WONT` ou `NAO AVALIAVEL`. Citar o ID da regra e a evidência concreta.

Não marcar `CONFORME` sem evidência suficiente.

### 5. Aplicar o gate universal

Uma violação comprovada de `UX-CORE-*` recebe a severidade-base do UX_STANDARD: `MUST` em todos os princípios universais, exceto `UX-CORE-008`, que nasce em `SHOULD`, salvo regra mais estrita do projeto. Conflito relevante entre DEFINE e UX_STANDARD é `MUST`.

### 6. Revisar as dimensões da experiência

Cobrir clareza, eficiência, confiança, contexto da empresa ativa, navegação, hierarquia, densidade, formulários progressivos, revisão final, acessibilidade, responsividade, estados, copy, feedback, recuperação e consistência.

### 7. Revisar os estados

Tratar loading, empty, error, success, partial data, permission denied e disabled quando aplicáveis. A ausência de um estado essencial capaz de quebrar a tarefa é `MUST`.

Também revisar a distinção entre rascunho, salvando, salvo, processando, emitido, erro e cancelado quando a feature envolver emissão.

### 8. Revisar contexto multiempresa

Quando o perfil Escritório estiver envolvido, verificar se empresa/CNPJ ativo permanece visível e inequívoco durante a ação central, revisão e confirmação. Mudanças de empresa devem gerar feedback claro.

### 9. Revisar emissão e revisão final

Quando a feature permitir transmissão/emissão:
- exigir revisão final;
- mostrar empresa, tomador, operação e valor;
- destacar alertas críticos;
- impedir duplo envio durante processamento;
- nomear claramente o CTA final;
- oferecer confirmação de sucesso e próximos passos.

### 10. Revisar acessibilidade e responsividade

Usar WCAG 2.2 AA como referência formal definida no UX_STANDARD. Não declarar conformidade sem evidência/medição suficiente. Marcar itens não comprováveis como `NAO AVALIAVEL`.

Desktop é o contexto principal. Celular deve suportar consulta e emissão simples, preservando informações críticas.

### 11. Avaliar gamificação apenas quando aplicável

O padrão atual define gamificação como não recomendada no fluxo fiscal principal. Não propor streaks, urgência artificial, pontos ou mecânicas que incentivem emissão apressada.

### 12. Produzir o handoff para o Design

Escrever requisitos de comportamento, componentes necessários, estados, copy, direção visual, acessibilidade, responsividade e critérios de aceite.

Não desenhar arquitetura técnica nem substituir o Design.

### 13. Determinar o resultado do gate

- Sem `MUST`: `READY FOR DESIGN`, mantendo SHOULD/COULD no handoff.
- Com `MUST` não resolvido: `BLOCKED FOR DESIGN`.
- Com `MUST` aceito explicitamente: registrar exceção e responsável; não marcar como conforme.

### 14. Tratar evolução do padrão

Se a revisão mostrar que o UX_STANDARD precisa mudar, registrar uma `Proposta de evolução canônica`. Não editar a fonte canônica: encaminhar a mudança para a meta-skill `ux-review-builder`, no modo Evolução.

## Validações e checklist de qualidade

- jornada mapeada;
- regras canônicas aplicáveis identificadas;
- riscos críticos revisados quando aplicáveis;
- contexto da empresa ativa revisado em fluxos multiempresa;
- revisão final obrigatória verificada em features de emissão;
- achados com IDs e evidências;
- nenhum `CONFORME` sem evidência;
- dez princípios universais considerados;
- estados essenciais avaliados;
- rascunho e transmissão diferenciados quando aplicável;
- acessibilidade e responsividade tratadas;
- copy e feedback tratados;
- conflito DEFINE x UX_STANDARD bloqueado;
- `MUST` bloqueia o Design, salvo aceite explícito;
- nenhuma mudança automática no UX_STANDARD;
- handoff concreto para o Design;
- relatório gravado na pasta do SDD, sem subpastas.

## Tratamento de exceções

**UX_STANDARD ausente:** bloquear a conclusão e pedir a fonte canônica.

**DEFINE ausente:** bloquear a conclusão e pedir o documento do Define da feature.

**Regra ambígua:** marcar `NAO AVALIAVEL` e abrir pergunta. Não inventar interpretação canônica.

**Evidência visual insuficiente:** revisar o que o DEFINE e o padrão permitem e marcar o restante como `NAO AVALIAVEL`.

**Pedido para mudar o padrão:** registrar a sugestão e encaminhar à governança; não editar.

**MUST aceito:** registrar aceite, motivo e responsável. O achado continua sendo violação aceita.

## Examples

**Conforme.** `UX-FORM-002` exige revisão final e o fluxo mostra empresa, tomador, operação e valor antes da transmissão. Registrar `CONFORME` com evidência.

**MUST.** O perfil Escritório pode concluir emissão sem identificar claramente a empresa ativa, violando `UX-NAV-001` e `UX-VIS-004`. Registrar `MUST` e `BLOCKED FOR DESIGN`.

**MUST.** O sistema permite enviar novamente enquanto a emissão anterior ainda está processando, violando `UX-CORE-002`, `UX-CORE-007` e `UX-INT-006`.

**Não avaliável.** O UX_STANDARD exige foco visível, mas não há mockup nem comportamento implementado. Marcar `NAO AVALIAVEL`; não afirmar conformidade.

## Texto canônico de recusa

"Não vou alterar o UX_STANDARD.md durante esta revisão. Posso registrar a mudança proposta para o fluxo de governança."

"Existe um MUST pendente; o gate permanece bloqueado para o Design até correção ou aceite explícito do responsável."

## Base documental

Fonte canônica: `UX_STANDARD.md`. Formato de saída: `UX_REVIEW_TEMPLATE.md`. Requisitos funcionais: o DEFINE da feature. Os três ficam na pasta do SDD, lado a lado.

## Inventário do bundle

Esta skill é gerada pela `ux-review-builder` e instalada como skill do projeto no agente que executa o SDD. Ela depende dos documentos obrigatórios da pasta do SDD.

## Metodologia e autoria

Esta skill foi construída com a metodologia de Roberto Dias Duarte.
